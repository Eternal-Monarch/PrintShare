(() => {
'use strict';
const $ = s => document.querySelector(s);
const state = { docs: [], base: '', setup: false, maxMB: 100, tunnel: null, sel: new Set(), q: '' };
pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdfjs/pdf.worker.min.js';

/* ---------- tiny helpers ---------- */
function h(tag, props = {}, ...kids) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = v;
    else if (k.startsWith('on')) e.addEventListener(k.slice(2), v);
    else if (v !== false && v != null) e.setAttribute(k, v);
  }
  kids.flat().forEach(c => c != null && e.append(c));
  return e;
}
function icon(name) {
  const NS = 'http://www.w3.org/2000/svg';
  const s = document.createElementNS(NS, 'svg'); s.setAttribute('class', 'ic');
  const u = document.createElementNS(NS, 'use'); u.setAttribute('href', '#i-' + name);
  s.append(u); return s;
}
const fmtSize = b => b < 1024 ? b + ' B' : b < 1048576 ? (b / 1024).toFixed(0) + ' KB' : b < 1073741824 ? (b / 1048576).toFixed(1) + ' MB' : (b / 1073741824).toFixed(2) + ' GB';
const fmtDate = iso => new Date(iso).toLocaleString([], { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
let toastTimer;
function toast(msg, bad) {
  const t = $('#toast'); t.textContent = msg; t.className = 'toast show' + (bad ? ' bad' : '');
  clearTimeout(toastTimer); toastTimer = setTimeout(() => t.classList.remove('show'), 2600);
}
async function api(url, opts = {}) {
  const o = { method: opts.method || 'GET', headers: {}, credentials: 'same-origin' };
  if (opts.body !== undefined) { o.headers['Content-Type'] = 'application/json'; o.body = JSON.stringify(opts.body); }
  const r = await fetch(url, o);
  let data = {}; try { data = await r.json(); } catch {}
  if (r.status === 401 && !opts.quiet) showAuth(false);
  if (!r.ok) throw Object.assign(new Error(data.error || 'Request failed.'), { status: r.status });
  return data;
}
document.addEventListener('click', e => {
  const c = e.target.closest('[data-close]'); if (c) c.closest('dialog').close();
});

/* ---------- login / setup ---------- */
function showAuth(setup) {
  if (typeof setup === 'boolean') state.setup = setup;
  $('#shell').hidden = true; $('#auth').hidden = false;
  $('#authTitle').textContent = state.setup ? 'Create your admin password' : 'Sign in to PrintShare';
  $('#authText').textContent = state.setup ? 'This password protects your dashboard. Use at least 8 characters.' : 'Enter your admin password.';
  $('#authPw2Wrap').hidden = !state.setup; $('#authPw2').required = state.setup;
  $('#authPw').autocomplete = state.setup ? 'new-password' : 'current-password';
  $('#authBtn').textContent = state.setup ? 'Create password' : 'Sign in';
  $('#authErr').textContent = ''; $('#authPw').value = ''; $('#authPw2').value = '';
  $('#authPw').focus();
}
$('#authForm').addEventListener('submit', async e => {
  e.preventDefault();
  const pw = $('#authPw').value;
  if (state.setup && pw !== $('#authPw2').value) { $('#authErr').textContent = 'The two passwords do not match.'; return; }
  try {
    await api(state.setup ? '/api/admin/setup' : '/api/admin/login', { method: 'POST', body: { password: pw }, quiet: true });
    enter();
  } catch (err) { $('#authErr').textContent = err.message; }
});
$('#btnLogout').addEventListener('click', async () => {
  try { await api('/api/admin/logout', { method: 'POST', quiet: true }); } catch {}
  showAuth(false);
});

/* ---------- status pills ---------- */
function setPill(id, cls, text) {
  const p = $(id); p.className = 'pill ' + cls; p.querySelector('em').textContent = text;
}
async function refreshStatus() {
  try {
    const s = await api('/api/admin/status', { quiet: true });
    state.maxMB = s.maxFileMB;
    setPill('#pillServer', 'ok', 'Running');
    const t = s.tunnel;
    if (t.running && t.reachable) setPill('#pillTunnel', 'ok', 'Connected');
    else if (t.running) setPill('#pillTunnel', 'warn', 'Connecting…');
    else setPill('#pillTunnel', 'bad', 'Not running');
    $('#statCount').textContent = s.count; $('#statSize').textContent = fmtSize(s.storage);
    const fr = $('#statFree'); fr.textContent = s.disk ? fmtSize(s.disk.free) : '–'; fr.classList.toggle('low', !!s.disk && s.disk.free < 1073741824);
    $('#dropHint').textContent = `PDF only · up to ${s.maxFileMB} MB each · several files at once are fine`;
    const changed = state.base !== (s.baseUrl || '');
    state.base = s.baseUrl || ''; state.tunnel = t;
    const n = $('#baseNotice');
    if (!t.running) { n.hidden = false; n.textContent = 'The Cloudflare Tunnel is not running, so links will not work from other computers yet. Close this and double-click START.bat again (see the README).'; }
    else if (!t.reachable) { n.hidden = false; n.textContent = 'The tunnel is starting. Links will work in a few seconds…'; }
    else n.hidden = true;
    if (changed) renderDocs();
  } catch (err) {
    if (err.status === 401) return;
    setPill('#pillServer', 'bad', 'Offline'); setPill('#pillTunnel', 'bad', 'Unknown');
  }
}

/* ---------- documents ---------- */
const shareUrl = d => (state.base || location.origin) + '/print/' + d.id;
async function loadDocs() {
  const r = await api('/api/admin/docs');
  state.docs = r.documents; renderDocs();
  state.docs.filter(d => !d.pages).forEach(countPages);
}
async function countPages(d) {
  try {
    const pdf = await pdfjsLib.getDocument({ url: `/api/admin/docs/${d.id}/file`, isEvalSupported: false }).promise;
    const r = await api(`/api/admin/docs/${d.id}/pages`, { method: 'POST', body: { pages: pdf.numPages } });
    Object.assign(d, r.document); pdf.destroy(); renderDocs();
  } catch {}
}
function renderDocs(newId) {
  const list = $('#list'); list.replaceChildren();
  if (!state.docs.length) {
    list.append(h('div', { class: 'empty' }, h('strong', { text: 'No documents yet' }), h('p', { text: 'Drop a PDF above to create your first print link.' })));
    updateBar(); return;
  }
  state.sel.forEach(id => { if (!state.docs.some(d => d.id === id)) state.sel.delete(id); });
  const vis = visible();
  if (!vis.length) { list.append(h('div', { class: 'empty' }, h('strong', { text: 'No documents match your search' }))); updateBar(); return; }
  for (const d of vis) {
    const url = shareUrl(d);
    const input = h('input', { type: 'text', readonly: '', value: url, 'aria-label': 'Sharing link' });
    input.addEventListener('focus', () => input.select());
    const btn = h('button', { class: 'btn primary' });
    setBtn(btn, 'copy', 'Copy link');
    btn.addEventListener('click', () => copyText(url, () => flashCopied(btn, 'copy', 'Copy link', 'Copied')));
    const pick = h('input', { type: 'checkbox', 'aria-label': 'Select ' + d.name });
    pick.checked = state.sel.has(d.id);
    pick.addEventListener('change', () => { pick.checked ? state.sel.add(d.id) : state.sel.delete(d.id); updateBar(); });
    list.append(h('article', { class: 'card' + (d.id === newId ? ' new' : '') },
      h('label', { class: 'pick', title: 'Select' }, pick),
      h('div', { class: 'file-ic' }, icon('file')),
      h('div', { class: 'c-info' },
        h('div', { class: 'c-name', title: d.name, text: d.name }),
        h('div', { class: 'c-meta' },
          h('span', { text: fmtSize(d.size) }),
          h('span', { text: d.pages ? `${d.pages} page${d.pages === 1 ? '' : 's'}` : 'counting pages…' }),
          h('span', { text: fmtDate(d.createdAt) }),
          h('span', { text: `Opened ${d.views || 0}× · Print started ${d.prints || 0}×` }),
          expiryBadge(d),
          d.note ? h('span', { class: 'badge' }, icon('note'), 'Instructions') : null,
          d.protected ? h('span', { class: 'badge' }, icon('lock'), 'Password') : null,
          d.strict ? h('span', { class: 'badge' }, icon('shield'), d.locked ? 'One device · claimed' : 'One device · unclaimed') : null,
          d.once ? h('span', { class: 'badge ' + (d.printedAt ? 'ok' : d.used ? 'warn' : '') }, icon(d.printedAt ? 'check' : 'shield'), d.printedAt ? 'Printed ✓ (confirmed by shop)' : d.used ? 'Opened once · link closed' : 'One-time link') : null)),
      h('div', { class: 'c-actions' },
        h('button', { class: 'icon-btn', title: 'Preview', onclick: () => openPreview(d) }, icon('eye')),
        h('button', { class: 'icon-btn', title: 'Printing instructions for the shop', onclick: () => openNote(d) }, icon('note')),
        h('button', { class: 'icon-btn', title: 'QR code', onclick: () => openQr(d) }, icon('qr')),
        h('button', { class: 'icon-btn', title: 'Access rules', onclick: () => openAcc(d) }, icon('shield')),
        h('button', { class: 'icon-btn', title: 'Password', onclick: () => openPw(d) }, icon('lock')),
        moreMenu(d)),
      h('div', { class: 'c-link' }, input, btn,
        h('a', { class: 'btn small', href: waUrl(shareText(d)), target: '_blank', rel: 'noopener noreferrer' }, 'WhatsApp'),
        h('a', { class: 'btn small', href: mailUrl(d.name, shareText(d)), target: '_blank', rel: 'noopener noreferrer' }, 'Email'))));
  }
  updateBar();
}
/* ---------- copy / share helpers ---------- */
const visible = () => { const q = state.q.trim().toLowerCase(); return state.docs.filter(d => !q || d.name.toLowerCase().includes(q)); };
const uploadOrder = () => visible().reverse(); // oldest first
const shareText = d => `${d.name}\n${shareUrl(d)}`;                       // WhatsApp / Email (one file)
const linksText = list => list.length === 1 ? shareUrl(list[0]) : list.map((d, i) => `${i + 1}. ${d.name}\n${shareUrl(d)}`).join('\n\n'); // many files
const waUrl = text => 'https://wa.me/?text=' + encodeURIComponent(text);
const mailUrl = (subject, text) => `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(text)}`;
function expiryBadge(d) {
  if (!d.expiresAt) return null;
  if (d.expired) return h('span', { class: 'badge bad' }, icon('lock'), 'Expired');
  const m = Math.max(1, Math.round((Date.parse(d.expiresAt) - Date.now()) / 60000));
  const t = m < 60 ? `${m} min` : m < 2880 ? `${Math.round(m / 60)} h` : `${Math.round(m / 1440)} days`;
  return h('span', { class: 'badge warn' }, icon('lock'), `Expires in ${t}`);
}
function setBtn(btn, ic, text) { btn.replaceChildren(icon(ic), text); }
function flashCopied(btn, ic, text, doneText) {
  clearTimeout(btn._t); btn.parentNode.querySelectorAll('.copied-tag').forEach(n => n.remove());
  setBtn(btn, 'check', doneText); btn.classList.add('ok');
  const tag = h('span', { class: 'copied-tag' }, icon('check'), doneText);
  btn.after(tag);
  btn._t = setTimeout(() => { btn.classList.remove('ok'); setBtn(btn, ic, text); tag.remove(); }, 3000);
}
function selectedList() {
  const vis = uploadOrder(); const picked = vis.filter(d => state.sel.has(d.id));
  return picked.length ? picked : vis;
}
function updateBar() {
  const n = visible().length, s = visible().filter(d => state.sel.has(d.id)).length;
  $('#listBar').hidden = state.docs.length === 0; $('#delSel').hidden = s === 0;
  $('#selAll').checked = n > 0 && s === n; $('#selAll').indeterminate = s > 0 && s < n;
  $('#selInfo').textContent = s ? `${s} selected` : `${n} document${n === 1 ? '' : 's'}`;
  const btn = $('#copyAll');
  if (!btn.classList.contains('ok')) setBtn(btn, 'copy', s ? `Copy ${s} link${s === 1 ? '' : 's'}` : 'Copy all links');
}
$('#selAll').addEventListener('change', e => {
  visible().forEach(d => e.target.checked ? state.sel.add(d.id) : state.sel.delete(d.id));
  document.querySelectorAll('#list .pick input').forEach(i => { i.checked = e.target.checked; }); updateBar();
});
$('#search').addEventListener('input', e => { state.q = e.target.value; renderDocs(); });
$('#copyAll').addEventListener('click', () => {
  const list = selectedList(); if (!list.length) return;
  const btn = $('#copyAll');
  copyListRich(list, () => {
    clearTimeout(btn._t); btn.parentNode.querySelectorAll('.copied-tag').forEach(n => n.remove());
    setBtn(btn, 'check', `Copied ${list.length} link${list.length === 1 ? '' : 's'}`); btn.classList.add('ok');
    const tag = h('span', { class: 'copied-tag' }, icon('check'), list.length > 1 ? 'as a table with blue links' : 'link only'); btn.after(tag);
    btn._t = setTimeout(() => { btn.classList.remove('ok'); tag.remove(); updateBar(); }, 3000);
  });
});
$('#shareWa').addEventListener('click', () => { const l = selectedList(); if (l.length) window.open(waUrl(linksText(l)), '_blank', 'noopener'); });
$('#shareMail').addEventListener('click', () => { const l = selectedList(); if (l.length) window.open(mailUrl(l.length === 1 ? l[0].name : 'Documents to print', linksText(l)), '_blank', 'noopener'); });

/* Rich copy: Gmail gets a 2-column table with blue clickable links, WhatsApp/other boxes get clean text. */
const esc = t => String(t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
function linksHtml(list) {
  const cell = 'border:1px solid #c7ccd6;padding:6px 12px;text-align:left;vertical-align:top';
  const rows = list.map(d => `<tr><td style="${cell}">${esc(d.name)}</td><td style="${cell}"><a href="${esc(shareUrl(d))}" style="color:#1155cc;text-decoration:underline">${esc(shareUrl(d))}</a></td></tr>`).join('');
  return `<table style="border-collapse:collapse;font-family:Arial,Helvetica,sans-serif;font-size:14px"><thead><tr><th style="${cell};background:#eef2fa">File name</th><th style="${cell};background:#eef2fa">Print link</th></tr></thead><tbody>${rows}</tbody></table>`;
}
async function copyListRich(list, ok) {
  if (list.length < 2) return copyText(linksText(list), ok);
  const html = linksHtml(list), text = linksText(list);
  try {
    if (navigator.clipboard && window.ClipboardItem) {
      await navigator.clipboard.write([new ClipboardItem({ 'text/html': new Blob([html], { type: 'text/html' }), 'text/plain': new Blob([text], { type: 'text/plain' }) })]);
      return ok();
    }
  } catch {}
  const box = h('div', { style: 'position:fixed;left:-9999px;top:0' }); box.innerHTML = html; document.body.append(box);
  const range = document.createRange(); range.selectNodeContents(box);
  const sel = getSelection(); sel.removeAllRanges(); sel.addRange(range);
  let done = false; try { done = document.execCommand('copy'); } catch {}
  sel.removeAllRanges(); box.remove();
  done ? ok() : copyText(text, ok);
}

function copyText(text, ok) {
  const fallback = () => {
    const t = h('textarea', { style: 'position:fixed;opacity:0' }); t.value = text; document.body.append(t); t.select();
    try { document.execCommand('copy'); ok(); } catch { toast('Select the link and press Ctrl+C', true); }
    t.remove();
  };
  if (navigator.clipboard) navigator.clipboard.writeText(text).then(ok, fallback); else fallback();
}

/* ---------- upload ---------- */
const drop = $('#drop'), fileInput = $('#fileInput');
drop.addEventListener('click', () => fileInput.click());
drop.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); fileInput.click(); } });
['dragenter', 'dragover'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.add('over'); }));
['dragleave', 'drop'].forEach(ev => drop.addEventListener(ev, e => { e.preventDefault(); drop.classList.remove('over'); }));
drop.addEventListener('drop', e => handleFiles(e.dataTransfer.files));
fileInput.addEventListener('change', () => { handleFiles(fileInput.files); fileInput.value = ''; });
window.addEventListener('dragover', e => e.preventDefault());
window.addEventListener('drop', e => e.preventDefault());

let chain = Promise.resolve();
function handleFiles(files) {
  for (const f of files) {
    const bar = h('div'), status = h('span', { class: 'up-status', text: 'Waiting…' });
    const row = h('div', { class: 'up-item' }, h('div', { class: 'up-name', text: f.name }), status, h('div', { class: 'up-bar' }, bar));
    $('#queue').append(row);
    const fail = msg => { status.textContent = msg; status.className = 'up-status err'; };
    if (!/\.pdf$/i.test(f.name) || (f.type && f.type !== 'application/pdf')) { fail('Not a PDF'); continue; }
    if (f.size > state.maxMB * 1048576) { fail(`Over ${state.maxMB} MB`); continue; }
    chain = chain.then(() => uploadOne(f, bar, status, row, fail));
  }
}
function uploadOne(file, bar, status, row, fail) {
  return new Promise(resolve => {
    const fd = new FormData(); fd.append('files', file, file.name);
    const x = new XMLHttpRequest();
    x.open('POST', '/api/admin/upload');
    x.upload.onprogress = e => {
      if (!e.lengthComputable) return;
      const p = Math.round(e.loaded / e.total * 100);
      bar.style.width = p + '%'; status.textContent = p < 100 ? p + '%' : 'Processing…';
    };
    x.onload = () => {
      let d = {}; try { d = JSON.parse(x.responseText); } catch {}
      if (x.status === 200 && d.documents && d.documents.length) {
        bar.style.width = '100%'; status.textContent = 'Done'; status.className = 'up-status done';
        state.docs.unshift(...d.documents); renderDocs(d.documents[0].id); refreshStatus();
        d.documents.filter(z => !z.pages).forEach(z => countPages(state.docs.find(q => q.id === z.id)));
        setTimeout(() => row.remove(), 2500);
      } else { if (x.status === 401) showAuth(false); fail(d.error || 'Upload failed'); }
      resolve();
    };
    x.onerror = () => { fail('Network error'); resolve(); };
    x.send(fd);
  });
}

/* ---------- preview ---------- */
const pv = { pdf: null, n: 1, token: 0 };
async function openPreview(d) {
  $('#pvTitle').textContent = d.name; $('#pvMsg').textContent = 'Loading…';
  $('#pvCanvas').style.display = 'none'; $('#dlgPreview').showModal();
  try {
    if (pv.pdf) pv.pdf.destroy();
    pv.pdf = await pdfjsLib.getDocument({ url: `/api/admin/docs/${d.id}/file`, isEvalSupported: false }).promise;
    pv.n = 1; await pvRender();
  } catch { $('#pvMsg').textContent = 'Could not open this PDF.'; }
}
async function pvRender() {
  const tok = ++pv.token, page = await pv.pdf.getPage(pv.n);
  const stage = document.querySelector('.pv-stage');
  const w = Math.min(stage.clientWidth - 28, 900);
  const v1 = page.getViewport({ scale: 1 }), scale = w / v1.width, dpr = window.devicePixelRatio || 1;
  const vp = page.getViewport({ scale: scale * dpr }), c = $('#pvCanvas');
  c.width = vp.width; c.height = vp.height; c.style.width = vp.width / dpr + 'px'; c.style.height = vp.height / dpr + 'px';
  await page.render({ canvasContext: c.getContext('2d'), viewport: vp }).promise;
  if (tok !== pv.token) return;
  c.style.display = 'block'; $('#pvMsg').textContent = '';
  $('#pvPage').textContent = `${pv.n} / ${pv.pdf.numPages}`;
  $('#pvPrev').disabled = pv.n <= 1; $('#pvNext').disabled = pv.n >= pv.pdf.numPages;
}
$('#pvPrev').addEventListener('click', () => { if (pv.n > 1) { pv.n--; pvRender(); } });
$('#pvNext').addEventListener('click', () => { if (pv.pdf && pv.n < pv.pdf.numPages) { pv.n++; pvRender(); } });
$('#dlgPreview').addEventListener('close', () => { if (pv.pdf) { pv.pdf.destroy(); pv.pdf = null; } });

/* ---------- password ---------- */
let pwDoc = null;
function openPw(d) {
  pwDoc = d; $('#pwDoc').textContent = d.name; $('#pwInput').value = ''; $('#pwErr').textContent = '';
  $('#dlgPw').showModal(); $('#pwInput').focus();
}
$('#pwForm').addEventListener('submit', async e => {
  e.preventDefault();
  const v = $('#pwInput').value;
  try {
    const r = await api(`/api/admin/docs/${pwDoc.id}/password`, { method: 'POST', body: { password: v === '' ? null : v } });
    Object.assign(pwDoc, r.document); renderDocs(); $('#dlgPw').close();
    toast(v === '' ? 'Password removed' : 'Password saved');
  } catch (err) { $('#pwErr').textContent = err.message; }
});

/* ---------- access rules ---------- */
let accDoc = null;
function accRefresh() {
  $('#accState').textContent = !$('#accStrict').checked ? 'Anyone with the link can open it (VPN allowed).'
    : accDoc.locked ? `Claimed by ${accDoc.lockIp} on ${fmtDate(accDoc.lockedAt)}. Other networks are refused.` : 'Not opened yet. The first visitor will claim it.';
  $('#accRelease').hidden = !(accDoc.strict && accDoc.locked && !accDoc.once);
  $('#accRearm').hidden = !(accDoc.once && accDoc.used);
  $('#accExp').textContent = accDoc.expiresAt ? (accDoc.expired ? `Expired on ${fmtDate(accDoc.expiresAt)}.` : `Expires on ${fmtDate(accDoc.expiresAt)}.`) : 'This link never expires.';
}
function openAcc(d) {
  accDoc = d; $('#accDoc').textContent = d.name; $('#accStrict').checked = !!d.strict; $('#accOnce').checked = !!d.once; $('#accExpiry').value = ''; $('#accErr').textContent = '';
  accRefresh(); $('#dlgAcc').showModal();
}
$('#accStrict').addEventListener('change', accRefresh);
$('#accForm').addEventListener('submit', async e => {
  e.preventDefault();
  const ex = $('#accExpiry').value, body = { strict: $('#accStrict').checked, once: $('#accOnce').checked };
  if (ex === 'never') body.expireHours = null; else if (ex) body.expireHours = Number(ex);
  try {
    const r = await api(`/api/admin/docs/${accDoc.id}/access`, { method: 'POST', body });
    Object.assign(accDoc, r.document); renderDocs(); $('#dlgAcc').close(); toast('Access rules saved');
  } catch (err) { $('#accErr').textContent = err.message; }
});
$('#accRelease').addEventListener('click', async () => {
  try {
    const r = await api(`/api/admin/docs/${accDoc.id}/access`, { method: 'POST', body: { release: true } });
    Object.assign(accDoc, r.document); renderDocs(); accRefresh(); toast('Lock released');
  } catch (err) { $('#accErr').textContent = err.message; }
});

$('#accRearm').addEventListener('click', async () => {
  try {
    const r = await api(`/api/admin/docs/${accDoc.id}/access`, { method: 'POST', body: { reset: true } });
    Object.assign(accDoc, r.document); renderDocs(); accRefresh(); toast('Link re-armed: it can be opened once more');
  } catch (err) { $('#accErr').textContent = err.message; }
});

/* ---------- rename ---------- */
let renDoc = null;
function openRen(d) { renDoc = d; $('#renInput').value = d.name; $('#renErr').textContent = ''; $('#dlgRen').showModal(); $('#renInput').select(); }
$('#renForm').addEventListener('submit', async e => {
  e.preventDefault();
  try {
    const r = await api(`/api/admin/docs/${renDoc.id}/rename`, { method: 'POST', body: { name: $('#renInput').value } });
    Object.assign(renDoc, r.document); renderDocs(); $('#dlgRen').close(); toast('Renamed');
  } catch (err) { $('#renErr').textContent = err.message; }
});

/* ---------- delete ---------- */
let delDoc = null;
function openDel(d) {
  delDoc = d; $('#delText').textContent = `"${d.name}" will be removed from this laptop and its link will stop working.`;
  $('#dlgDel').showModal();
}
$('#delOk').addEventListener('click', async () => {
  try {
    await api(`/api/admin/docs/${delDoc.id}`, { method: 'DELETE' });
    state.docs = state.docs.filter(x => x.id !== delDoc.id); renderDocs(); refreshStatus();
    $('#dlgDel').close(); toast('Deleted');
  } catch (err) { toast(err.message, true); }
});

/* ---------- settings ---------- */
$('#btnSettings').addEventListener('click', async () => {
  $('#setErr').textContent = '';
  try { const st = await api('/api/admin/settings'); $('#setUrl').value = st.publicUrl; $('#setAuto').checked = !!st.autoDeleteExpired; } catch {}
  $('#dlgSet').showModal();
});
$('#setForm').addEventListener('submit', async e => {
  e.preventDefault();
  try {
    await api('/api/admin/settings', { method: 'POST', body: { publicUrl: $('#setUrl').value, autoDeleteExpired: $('#setAuto').checked } });
    $('#dlgSet').close(); toast('Saved'); refreshStatus();
  } catch (err) { $('#setErr').textContent = err.message; }
});

/* ---------- more menu, confirm box, new link, bulk delete ---------- */
function moreMenu(d) {
  const close = () => { det.open = false; };
  const det = h('details', { class: 'more' },
    h('summary', { class: 'icon-btn', title: 'More' }, icon('more')),
    h('div', { class: 'menu' },
      h('button', { onclick: () => { close(); openRen(d); } }, icon('edit'), 'Rename'),
      h('button', { onclick: () => { close(); regenerate(d); } }, icon('refresh'), 'Make a new link'),
      h('button', { class: 'danger', onclick: () => { close(); openDel(d); } }, icon('trash'), 'Delete')));
  return det;
}
document.addEventListener('click', e => {
  document.querySelectorAll('details.more[open]').forEach(x => { if (!x.contains(e.target)) x.open = false; });
});
function confirmBox(title, text, okLabel) {
  return new Promise(resolve => {
    const dlg = $('#dlgConfirm');
    $('#cfTitle').textContent = title; $('#cfText').textContent = text; $('#cfOk').textContent = okLabel;
    dlg.returnValue = '';
    $('#cfOk').onclick = () => dlg.close('ok');
    dlg.onclose = () => { dlg.onclose = null; resolve(dlg.returnValue === 'ok'); };
    dlg.showModal();
  });
}
async function regenerate(d) {
  if (!await confirmBox('Make a new link?', `The current link for "${d.name}" will stop working immediately. Anyone who has it will need the new one.`, 'Make new link')) return;
  try {
    const r = await api(`/api/admin/docs/${d.id}/regenerate`, { method: 'POST' });
    Object.assign(d, r.document); state.sel.delete(d.id); renderDocs(d.id); toast('New link created. The old link no longer works.');
  } catch (err) { toast(err.message, true); }
}
$('#delSel').addEventListener('click', async () => {
  const ids = [...state.sel].filter(id => state.docs.some(d => d.id === id)); if (!ids.length) return;
  if (!await confirmBox(`Delete ${ids.length} file${ids.length === 1 ? '' : 's'}?`, 'They will be removed from this laptop and their links will stop working.', 'Delete')) return;
  for (const id of ids) { try { await api(`/api/admin/docs/${id}`, { method: 'DELETE' }); } catch {} }
  state.docs = state.docs.filter(d => !ids.includes(d.id)); state.sel.clear(); renderDocs(); refreshStatus(); toast('Deleted');
});

/* ---------- printing instructions ---------- */
let noteDoc = null;
const CHIPS = ['A4', 'A3', 'Letter', 'Black & white', 'Colour', 'Double-sided', 'Single-sided', 'Staple', '1 copy', '2 copies', 'Original size'];
CHIPS.forEach(c => $('#noteChips').append(h('button', { type: 'button', class: 'chip', text: c, onclick: () => {
  const t = $('#noteInput'); t.value += (t.value && !/[\s,]$/.test(t.value) ? ', ' : '') + c; t.focus();
} })));
function openNote(d) { noteDoc = d; $('#noteDoc').textContent = d.name; $('#noteInput').value = d.note || ''; $('#noteErr').textContent = ''; $('#dlgNote').showModal(); $('#noteInput').focus(); }
$('#noteForm').addEventListener('submit', async e => {
  e.preventDefault();
  try {
    const r = await api(`/api/admin/docs/${noteDoc.id}/note`, { method: 'POST', body: { note: $('#noteInput').value } });
    Object.assign(noteDoc, r.document); renderDocs(); $('#dlgNote').close(); toast('Instructions saved');
  } catch (err) { $('#noteErr').textContent = err.message; }
});

/* ---------- QR code ---------- */
function openQr(d) {
  const url = shareUrl(d), qr = qrcode(0, 'M'); qr.addData(url); qr.make();
  $('#qrBox').innerHTML = qr.createSvgTag(6, 0, 'QR code for the print link', 'Print link');
  $('#qrDoc').textContent = d.name; $('#qrUrl').textContent = url; $('#dlgQr').showModal();
}

/* ---------- activity log ---------- */
const EV = { uploaded: ['Uploaded', ''], opened: ['Opened', 'ok'], print: ['Print started', 'ok'], printed: ['Printed ✓', 'ok'], blocked: ['Blocked', 'bad'], 'wrong-password': ['Wrong password', 'bad'], regenerated: ['New link', ''], deleted: ['Deleted', ''], 'auto-deleted': ['Auto-deleted', ''] };
async function loadActivity() {
  const box = $('#actList'); box.replaceChildren(h('p', { class: 'muted', text: 'Loading…' }));
  try {
    const r = await api('/api/admin/activity'); box.replaceChildren();
    if (!r.events.length) box.append(h('p', { class: 'muted', text: 'Nothing has happened yet.' }));
    for (const e of r.events) {
      const [label, tone] = EV[e.type] || [e.type, ''];
      box.append(h('div', { class: 'ev' },
        h('span', { class: 't', text: fmtDate(e.t) }),
        h('span', { class: 'badge' + (tone === 'bad' ? ' bad' : '') , text: label }),
        h('span', { class: 'n', title: e.name, text: e.name || '—' }),
        (e.ip || e.detail) ? h('span', { class: 'd', text: [e.ip, e.detail].filter(Boolean).join(' · ') }) : null));
    }
  } catch (err) { box.replaceChildren(h('p', { class: 'error', text: err.message })); }
}
$('#btnActivity').addEventListener('click', () => { $('#dlgAct').showModal(); loadActivity(); });
$('#actRefresh').addEventListener('click', loadActivity);
$('#actClear').addEventListener('click', async () => {
  if (!await confirmBox('Clear the activity log?', 'This only removes the history list. Your documents are not affected.', 'Clear')) return;
  try { await api('/api/admin/activity/clear', { method: 'POST' }); } catch {}
  loadActivity();
});

/* ---------- keep open/print counters fresh ---------- */
async function syncDocs() {
  try {
    const r = await api('/api/admin/docs', { quiet: true }); let changed = false;
    const ids = new Set(r.documents.map(d => d.id));
    for (const nd of r.documents) {
      const od = state.docs.find(x => x.id === nd.id);
      if (!od) { state.docs.push(nd); changed = true; }
      else if (JSON.stringify(od) !== JSON.stringify(nd)) { Object.assign(od, nd); changed = true; }
    }
    const before = state.docs.length; state.docs = state.docs.filter(d => ids.has(d.id));
    if (state.docs.length !== before) changed = true;
    if (changed) { state.docs.sort((x, y) => Date.parse(y.createdAt) - Date.parse(x.createdAt)); renderDocs(); }
  } catch {}
}
setInterval(() => { if (!$('#shell').hidden && !document.querySelector('dialog[open]')) syncDocs(); }, 10000);

/* ---------- start ---------- */
let timer;
async function enter() {
  $('#auth').hidden = true; $('#shell').hidden = false;
  try { await loadDocs(); } catch {}
  refreshStatus(); clearInterval(timer); timer = setInterval(refreshStatus, 8000);
}
(async () => {
  try {
    const s = await api('/api/admin/session', { quiet: true });
    if (s.authed) enter(); else showAuth(s.setupRequired);
  } catch { $('#shell').hidden = false; setPill('#pillServer', 'bad', 'Offline'); setPill('#pillTunnel', 'bad', 'Unknown'); }
})();
})();
